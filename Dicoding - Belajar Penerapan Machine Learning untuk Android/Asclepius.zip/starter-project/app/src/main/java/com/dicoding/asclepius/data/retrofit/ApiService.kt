package com.dicoding.asclepius.data.retrofit

import com.dicoding.asclepius.data.response.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET("test")
    suspend fun getNews(
        @Query("q") query: String,
        @Query("sortBy") sortBy: String,
        @Query("apiKey") apiKey: String
    ): Response
}