package com.dicoding.asclepius.view.activity

import android.content.ContentValues.TAG
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.dicoding.asclepius.R
import com.dicoding.asclepius.databinding.ActivityResultBinding

class ResultActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setActionBar()

        val result = intent.getStringExtra(EXTRA_RESULT)
        val prediction = intent.getStringExtra(EXTRA_PREDICT)
//        val score = intent.getStringExtra(EXTRA_SCORE)
        val data = intent.getStringExtra(EXTRA_IMAGE_URI)
        val imageUri = Uri.parse(data)


        if (imageUri != null && prediction != null && result != null) {
            showResult(imageUri, prediction, result)
        } else {
            showError("Data tidak lengkap.")
        }

        Log.d(TAG, "Image URI: $result")

    }

    private fun showResult(imageUri: Uri, prediction: String, result: String) {
        runOnUiThread {
            imageUri?.let {
                Log.d("Image URI", "showImage: $it")
                binding.resultImage.setImageURI(it)
            }
            result?.let {
                Log.d("Result", "showResult: $it")
                binding.scoreResult.text = result
            }
            binding.resultImage.setImageURI(imageUri)
            binding.resultText.text = prediction
            setResultTextColor(prediction)
        }
    }


    private fun showError(message: String) {
        runOnUiThread {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun setResultTextColor(prediction: String?) {
        if (prediction == "Cancer") {
            binding?.resultText?.setTextColor(ContextCompat.getColor(this, R.color.red))
        } else {
            binding?.resultText?.setTextColor(ContextCompat.getColor(this, R.color.green))
        }
    }

    fun setActionBar(){
        supportActionBar?.title = "Result"
        supportActionBar?.setDisplayShowCustomEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setBackgroundDrawable(ColorDrawable(getColor(R.color.colorPrimary)))
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.search, menu)
        return super.onCreateOptionsMenu(menu)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.history -> {
                val intent = Intent(this, HistoryActivity::class.java)
                startActivity(intent)
                true
            }

            R.id.article -> {
                val intent = Intent(this, ArticleActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }


    companion object {
        const val EXTRA_IMAGE_URI = "extra_image_uri"
        const val EXTRA_RESULT = "extra_result"
        const val EXTRA_PREDICT = "extra_predict"
        const val EXTRA_SCORE = "extra_score"
        const val EXTRA_INFERENCETIME = "extra_inference_time"
    }
}